Use this


```
digraph G {Hello->World}
```

to get 

```graphviz
digraph G {Hello->World}
```

with with Äüö

```graphviz
digraph G {Hello->World with Äüö}
```
