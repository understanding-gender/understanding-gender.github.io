---
header-includes:
    - \newtheorem{theorem}{Theorem}
---

Regular Text.

<div class="theorem">

This is my theorem with Äüö.
</div>

Regular Text.
