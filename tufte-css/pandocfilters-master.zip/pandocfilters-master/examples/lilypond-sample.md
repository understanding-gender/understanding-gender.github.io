---
header-includes:

    - \usepackage{lyluatex}

---


Use this

~~~~~~
```ly
\relative c' { c4 d e f g a b c }
```
~~~~~~

to get

```ly
\relative c' { c4 d e f g a b c }
```

and this

~~~~~~
`lilypond-score`{.ly staffsize=12}
~~~~~~

to get the score in `ly-score.ly` :

`lilypond-score`{.ly staffsize=12}
